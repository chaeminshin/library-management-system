﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Data;
using System.Data.SqlClient;

namespace BookList
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        static SqlConnection con = new SqlConnection("Data Source=(local)\\sqlexpress;Initial Catalog=group3 ;Trusted_Connection=true;");
        public Window1()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //BookListTable.ItemsSource 
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                con.Open();
                string sqlQuery =
                    "insert into dbo.Book(ISBN, Title, Author, Description, PublishedDate, Available) " + 
                    "values('"+ ISBN.Text+"', '"+ Title.Text+"', '" + Author.Text + "', '" + Description.Text + "', '" + PublishedDate.Text + "', 'Y')";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                int result = cmd.ExecuteNonQuery();
                if(result == 1)
                {
                    MessageBox.Show("Book added successfully.");
                }
            }
            catch (Exception ex)
            {
                Title.Text = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string sqlQuery = "select ISBN, Title, Author, PublishedDate, Available from Book;";

                SqlDataAdapter da = new SqlDataAdapter(sqlQuery, con);
                DataSet ds = new DataSet();
                con.Open();
                da.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ISBN.Text = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                    Title.Text = ds.Tables[0].Rows[i].ItemArray[1].ToString();
                    Author.Text = ds.Tables[0].Rows[i].ItemArray[2].ToString();
                    PublishedDate.Text = ds.Tables[0].Rows[i].ItemArray[3].ToString();
                }
            }
            catch (Exception ex)
            {
                Title.Text= ex.ToString();
            }
            finally
            {
                  con.Close();
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
